# Variable Wizard Screenshots — Annotations
# ALL WebCoRE screenshots are REFERENCE — showing how PistonCore SHOULD look
# ALL PistonCore screenshots show what is WRONG and needs fixing

---

## 01_pistoncore_variable_wizard_wrong.png — PISTONCORE (WRONG)
PistonCore's current variable wizard when type=Device is selected.
WRONG: Initial value shows a plain text input "Leave blank for default"
SHOULD BE: The full WebCoRE-style dropdown with multiple options (see 03)
Also visible in background: only when showing twice (lines 13 and 16) — bug

---

## 02_webcore_variable_type_dropdown.png — WEBCORE (REFERENCE)
WebCoRE variable wizard — type dropdown open showing all options.
Type dropdown has two sections:
  Basic: Dynamic, String (text), Boolean (true/false), Number (integer),
         Number (decimal), Large number (long), Date and Time,
         Date (date only), Time (time only), Device
  Advanced lists: Dynamic list, String list (text), Boolean list (true/false),
                  Number list (integer), Number list (decimal),
                  Large number list (long), Date and Time list,
                  Date list (date only), Time list (time only)
Also visible in background: define block shows "device light = Cave Light ;" — 
this proves the variable wizard IS saving correctly, just the UI is wrong.

---

## 03_webcore_variable_initial_value_dropdown.png — WEBCORE (REFERENCE)
WebCoRE variable wizard — initial value dropdown open.
Variable type is Boolean (true/false), name is "light on"
Initial value dropdown options:
  - Nothing selected (default)
  - Physical device(s)
  - Value
  - Variable  ← currently selected/highlighted
  - Expression
  - Argument
Below the dropdown: explanatory note text about what setting an initial value means
Assignment type section: "Dynamic (default)" button

---

## 04_webcore_variable_initial_value_variable_picker.png — WEBCORE (REFERENCE)
WebCoRE variable wizard — when "Variable" is selected as initial value type.
Shows a full picker with three sections:
  Local variables: device light (the variable just defined above)
  Global variables: device @Alert_Lights, device @Announcement_Sonos,
                    device @Door_Contacts_Exterior, device @Email_All,
                    device @IndoorLUX, device @Light_Sensor, device @Locks,
                    device @Notification_Text, device @Notification_Text_Push_All,
                    device @Notifications_Push, device @Presence_Sensor,
                    device @Presence_Sensor_All, device @Smoke_Detectors,
                    device @Speakers, device @Speakers_All, device @Speakers_Dot,
                    device @Tamper...
  System variables: dynamic $args, string $currentEventAttribute,
                    datetime $currentEventDate, integer $currentEventDelay,
                    string $currentEventDescription...
Each entry shows the type prefix (device, dynamic, string, datetime, integer)
before the variable name.

---

## 05_pistoncore_two_modals_open_at_once.png — PISTONCORE (WRONG)
PistonCore bug: Two wizard modals open simultaneously.
Statement type picker (Add a new statement) is open in background.
Condition/Group wizard (Add a new condition) is open on top of it.
These should NEVER both be open. Statement picker closes when item selected.
Condition wizard only opens when user clicks ghost text in the editor.

---

## 06_pistoncore_vs_webcore_blank_piston.png — BOTH SIDE BY SIDE
Left: WebCoRE blank new piston — shows:
  settings / end settings;
  define / + add a new variable / end define;
  execute
    + add a new statement
  end execute;
  NO "only when" anywhere on a blank piston

Right: PistonCore blank new piston — shows:
  (same header structure)
  settings / end settings;
  define / + add a new variable / end define;
  only when  ← WRONG — should not be here
    · add a new restriction
  (blank line)
  execute
    only when  ← WRONG — should not be here
      · · add a new trigger or condition
    · · add a new statement
  end execute;

FIX: In simple mode with no restrictions/triggers/conditions, 
hide BOTH "only when" blocks. Show only:
  execute
    · add a new statement
  end execute;

---

## 07_pistoncore_variable_wizard_device_type.png — PISTONCORE (WRONG)
PistonCore variable wizard with Device type selected.
Shows: type dropdown (Device) + variable name text field
Initial value: plain text "Leave blank for default" — WRONG
Should be: the multi-option dropdown matching WebCoRE (see 03 and 04)

---

## Summary of fixes needed for next session

### Fix 1 — editor.js: only when visibility
In SIMPLE mode: only show "only when" blocks if they have content.
Blank simple piston should show:
  execute
    · add a new statement
  end execute;
Nothing else inside execute on a blank piston.

### Fix 2 — wizard.js: two modals at once
Statement type picker clicking "Add an if" inserts the skeleton and CLOSES.
The condition wizard should NOT open automatically.
User clicks ghost text · add a new condition inside the if block to open it separately.
Root cause: _handleStatementType is probably calling _goConditionOrGroup() somewhere.

### Fix 3 — wizard.js: variable initial value UI
Replace the plain text input with a proper dropdown matching WebCoRE:
  Options: Nothing selected / Physical device(s) / Value / Variable / Expression / Argument
  When "Physical device(s)" → show full device picker
  When "Value" → show text input
  When "Variable" → show picker: Local variables / Global variables / System variables
  When "Expression" → show expression textarea
  When "Argument" → show text input (for piston arguments)
Also show the explanatory note text WebCoRE shows about what initial value means.

### Fix 4 — editor.js: comment format
Comments showing as "/ * * New Piston * /" with wrong spacing.
Should be: "/* * New Piston */"
Check _cm() function and how comment lines are built in _renderDocument().
