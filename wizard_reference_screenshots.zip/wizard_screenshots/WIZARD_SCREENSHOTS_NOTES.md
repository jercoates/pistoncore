# Wizard Reference Screenshots — Annotations for Claude
# Read this file before writing any wizard code.

---

## 13 — wizard_variable_type_picker.png
"Add a new variable" modal.
- Left dropdown: type selector. Two sections: Basic (Dynamic, String, Boolean, Number integer,
  Number decimal, Large number, Date and Time, Date only, Time only, Device) and
  Advanced lists (Dynamic list, String list, etc.)
- Right field: variable name text input
- Bottom: Back | ⚙ | Add more | Add (green)
- Currently selected type (Device) shows checkmark in dropdown list
- Modal is white, centered, ~580px wide — editor dimmed behind it

---

## 17 — wizard_condition_vs_group_first_step.png
First step when adding a condition — "Add a new condition" modal.
- Description text at top: "An IF block is the simplest decisional block..."
- Two side-by-side cards:
  LEFT: "Condition" (teal title) — "A condition is a single comparison between two or more
        operands, the basic building block of a decisional statement"
        Button: [Add a condition] — BLUE/teal
  RIGHT: "Group" (orange title) — "A group is a collection of conditions, with a logical
         operator between them, allowing for complex decisional statements"
         Button: [Add a group] — ORANGE
- Cancel button bottom left
- NO back button on this first step

---

## 18 — wizard_condition_what_to_compare.png
Step 2 — "What to compare" after choosing Condition.
- Title: "Add a new condition"
- Description: "A condition allows for a single comparison to be made between two expressions."
- Row 1: "What to compare" label with ⚠ warning icon (nothing selected yet)
  - Blue dropdown: "Physical device(s)"
  - Second dropdown: "Nothing selected" (device picker)
  - Third dropdown: "Nothing selected" (attribute/capability)
- Row 2: "What kind of comparison?" — blue dropdown showing "Select a comparison..."
- Bottom: Back | ⚙ | Add more | Add
- Key: ALL dropdowns are on ONE step — device, attribute, and comparison operator are
  all on the same wizard screen, not separate steps

---

## 22 — wizard_operator_list_conditions_and_triggers.png
Operator dropdown open — showing both sections.
- ORANGE bar at top: "Any of the selected devices" (aggregation toggle)
- Row: Physical device(s) | device Light | switch (attribute selected)
- "Which interaction" row: Any interaction (blue)
- "What kind of comparison?" dropdown OPEN showing:
  SECTION HEADER: "Conditions" (gray label, not selectable)
    changed, did not change, is, is any of, is not, is not any of,
    was, was any of, was not, was not any of
  SECTION HEADER: "Triggers" (gray label, not selectable)
    changes, changes away from, changes away from any of,
    changes to, changes to any of, event occurs,
    is any and stays any of, is away and stays away from...
- "is" is currently highlighted (selected)
- No lightning bolt icons on individual items — just grouped by section label

---

## 26 — wizard_condition_complete_add_more.png
Completed condition ready to add — "did not change" operator selected.
- Orange bar: "Any of the selected devices"
- Physical device(s) | device Light | switch
- Which interaction: Any interaction
- What kind of comparison: "did not change" (selected, blue)
- "In the last..." row appears: Value dropdown | number input (1) | time unit (hours)
- Bottom: Back | ⚙ | Add more (green) | Add (green)
- "Add more" adds this condition and immediately opens wizard again for another
- "Add" adds this condition and closes the wizard

---

## 28 — wizard_statement_type_picker_full.png
Statement type picker — opens when clicking "+ add a new statement".
- Title area: "Basic statements" section header (gray text, centered)
  Cards: If Block (blue button) | Action (green button) | Timer (orange button)
- "Advanced statements" section header
  Cards: Switch (blue) | Do Block (green) | On event (orange)
- Loop section (no header label, just cards):
  For Loop (orange) | For Each Loop (orange) | While Loop (orange)
  Repeat Loop (orange) | Break (red) | Exit (red)
- "From clipboard" section at bottom
- Each card has: icon, name, description text, colored button
- This IS a card grid — this is the ONE place card grids are correct
  (the wizard for conditions/actions is NOT card grids)

---

## 29 — wizard_action_device_picker_top.png
Action device picker — top of list. "Add a new action" modal.
- Description: "Actions represent a collection of tasks a device or group of devices
  have to perform. The Location virtual device provides a way to execute some
  non-device-specific tasks..."
- "Devices" label
- Blue selected bar: "Location" (currently selected)
- Search box: "Use the input box below to quickly search for devices" + text input + X clear
- [Select All] [Deselect All] buttons
- "Virtual devices" section header → Location
- "Physical devices" section header → alphabetical list:
  Air Quality, Announcement Sonos, Back Door, Back Door Lock, Back Yard-motion,
  Basement light, Basement Smoke detector, Basement Window, Basement-motion,
  Basment Gas, Bathroom Door, Bathroom Light, Bedroom, Cave 2, Cave Light,
  Cave Motion, Chicken Cam-motion, Chicken light...

---

## 30 — wizard_action_device_picker_globals.png
Action device picker — scrolled down to show globals and system vars.
- Continuing physical devices list (scrolled past)
- Global device variables section (no explicit header, just labeled with "device" prefix):
  device @Door_Contacts_Exterior
  device @Email_All
  device @IndoorLUX
  device @Light_Sensor
  device @Locks
  device @Notification_Text
  device @Notification_Text_Push_All
  device @Notifications_Push
  device @Presence_Sensor
  device @Presence_Sensor_All  ← currently highlighted/selected
  device @Smoke_Detectors
  device @Speakers
  device @Speakers_All
  device @Speakers_Dot
  device @Tamper
- "System variables" section header:
  device $currentEventDevice  []
  device $device              []
  device $devices             []
  device $location            []
  device $previousEventDevice []
- The [] brackets indicate empty/no current value

---

## 31 — wizard_action_device_picker_bottom_with_system_vars.png
Bottom of device picker — system variables section fully visible.
(Confirms system variables are always shown at the bottom of every device picker)

---

## 32 — wizard_task_with_device_command_picker.png
"Add a new task" modal — after device selected, picking command.
- Title: "Add a new task"
- "With..." section showing: {Light} (the selected device in orange/teal)
- "Do..." section: blue dropdown "Please select a command"
- Bottom: Cancel | ⚙ | Add more | Add
- Key: This is a SEPARATE modal from the action device picker.
  Flow is: pick device(s) → close that picker → this modal opens for command

---

## 38 — complex_piston_document_new_door_chime.png (NEW — from this session)
A real complex piston — "New Door / Window chime". Shows:
- Full comment header block (lines 1-14) including import code "4y24" — IGNORE backup codes
- define block with Device variables spanning multiple lines (Doors = many devices)
- Notes line: /* Notes: ... */ — a special comment line in the document
- execute block with nested if/then/else if/else/end if structure
- "or" keyword rendered at same indent level as conditions (line 46, 47)
- {Doors}'s and {Windows}'s rendered as orange device refs with apostrophe-s
- contact rendered as blue underlined attribute
- Trace markers on left: red bar line 28, timing labels (+1ms, +4ms)
- "then" used in status/read-only view (NOT "when true" — that's editor only)
- end execute; at line 64

---

## 39 — wizard_set_variable_task.png (NEW — from this session)
Set variable wizard — shown while editor is open behind it.
- Title: "Add a new task"
- "With..." row: Location (virtual device)
- "Do..." row: blue bar showing "location Set variable..."
- "Variable" section:
  - Left dropdown: "Variable" (type — could also be Global, etc.)
  - Right dropdown: "string Message" (picks from defined piston variables)
- "Value" section:
  - Left dropdown: "Expression" (value type)
  - Large text area below for expression input — shows: ""  (empty string)
- "Only during these modes" section: orange dropdown "Nothing selected"
- Bottom: Cancel | Delete (red) | ⚙ | Save (blue/teal)
- Key difference from condition wizard: buttons are Cancel | Delete | ⚙ | Save
  (not Back | Add more | Add — task wizard has Save/Delete not Add)

---

## Key Rules Extracted From All Screenshots:

1. WIZARD SIZE: Centered modal ~580px wide, white background, editor dimmed behind.
   NOT full screen. NOT card grids (except statement type picker — that's the one exception).

2. CONDITION WIZARD FLOW:
   Step 0 (conditions only): Condition vs Group cards
   Step 1: What to compare — device dropdown + device picker + attribute — ALL ON ONE SCREEN
   Step 1b: Aggregation orange bar appears when multiple devices selected
   Step 1c: "Which interaction" row appears for trigger operators
   Step 2: Operator dropdown (Conditions section / Triggers section)
   Step 3: Value input (appears inline below operator, varies by type)
   Buttons: Back | ⚙ | Add more | Add

3. ACTION WIZARD FLOW:
   Step 1: Statement type picker (card grid)
   Step 2 (if Action): Device picker (search + virtual + physical + globals + system vars)
   Step 3: Command picker — "Add a new task" modal with With.../Do... layout
   Step 4: Parameters (inline below command)
   Buttons: Cancel | Delete | ⚙ | Save

4. OPERATOR LIST: Two labeled sections "Conditions" and "Triggers" — no lightning bolt
   icons on items, just grouped by section header.

5. DEVICE REFS in document: {DeviceName} in orange. Global device vars: {@GlobalName}.
   Attribute names: blue underlined text.

6. "or" / "and" between conditions: rendered at same indent as the conditions, not indented.

7. TASK wizard buttons differ from CONDITION wizard buttons:
   Condition: Back | ⚙ | Add more | Add
   Task: Cancel | Delete | ⚙ | Save
